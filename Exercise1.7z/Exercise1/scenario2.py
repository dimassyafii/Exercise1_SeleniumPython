from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

driver = webdriver.Chrome(executable_path="C:\\chromedriver.exe")
driver.maximize_window()
# 1. Go to www.ebay.com
driver.get("https://ebay.com/")
# 2.  Type any search string in the search bar. For example: MacBook
driver.find_element_by_id("gh-ac").send_keys("MacBook")
# 3. Change the Search category. For example: Computers/Tablets & Networking and click Search
driver.find_element_by_xpath("//select[@name='_sacat']/option[text()='Computers/Tablets & Networking']").click()
driver.find_element_by_xpath("//input[@value='Search']").click()
# 4.  Verify that the page loads completely
delay = 5
try:
    myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.LINK_TEXT, "Computers/Tablets & Networking")))
    print("Page is ready!")
except TimeoutException:
    print("Loading took too much time!")
finally:
    print("Page is Loaded!")
# 5.  Verify that the first result name matches with the search string.
textMatch = driver.find_element_by_xpath("//div[@id='srp-river-results']/ul[1]/li[1]/div[1]/div[2]/a[1]/h3[1]").text
assert ("MacBook" in textMatch)
print(textMatch)