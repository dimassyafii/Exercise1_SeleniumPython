import time
from selenium import webdriver

driver = webdriver.Chrome(executable_path="C:\\chromedriver.exe")
driver.maximize_window()
# 1. Go to www.gist.github.com
driver.get("https://github.com/login")
driver.find_element_by_name("login").send_keys("testgistgithub")
driver.find_element_by_name("password").send_keys("Exercise_2")
driver.find_element_by_name("commit").click()
driver.find_element_by_class_name("dropdown-caret").click()
driver.find_element_by_link_text("New gist").click()
time.sleep(3)
driver.find_element_by_name("gist[description]").send_keys("My First Gist")
driver.find_element_by_xpath("//input[@name='gist[contents][][name]']").send_keys("helloworld.py")
driver.find_element_by_xpath("//pre[@role='presentation']").send_keys("print('hello, world')")
driver.execute_script("window.scrollTo(0, 1000);")
driver.find_element_by_xpath("//div[@class='BtnGroup']/details").click()
driver.find_element_by_xpath("//input[@id='gist_public_1']/following-sibling::div[1]").click()
driver.find_element_by_xpath("//div[@class='BtnGroup']/button").click()
driver.find_element_by_xpath("//div[@id='user-links']/details[1]/summary[1]").click()
driver.find_element_by_xpath("//form[@class='logout-form']").click()
driver.find_element_by_xpath("//form/input[2]").click()