import time
from selenium import webdriver

driver = webdriver.Chrome(executable_path="C:\\chromedriver.exe")
driver.maximize_window()
driver.get("https://github.com/login")
driver.find_element_by_name("login").send_keys("testgistgithub")
driver.find_element_by_name("password").send_keys("Exercise_2")
driver.find_element_by_name("commit").click()
driver.get("https://gist.github.com")
driver.find_element_by_xpath("//span[contains(.,'helloworld_edit.py')]").click()
driver.find_element_by_xpath("//div[@class='px-0']/div/ul/li[2]/form/button").click()
driver.switch_to.alert.accept()
driver.switch_to.default_content()
driver.find_element_by_xpath("//div[@id='user-links']/details[1]/summary[1]").click()
driver.find_element_by_xpath("//form[@class='logout-form']").click()
driver.find_element_by_xpath("//form/input[2]").click()