import time
from selenium import webdriver

driver = webdriver.Chrome(executable_path="C:\\chromedriver.exe")
driver.maximize_window()
# 1. Go to www.gist.github.com
driver.get("https://github.com/login")
driver.find_element_by_name("login").send_keys("testgistgithub")
driver.find_element_by_name("password").send_keys("Exercise_2")
driver.find_element_by_name("commit").click()
driver.get("https://gist.github.com")
driver.find_element_by_xpath("//span[contains(.,'helloworld.py')]").click()
driver.find_element_by_xpath("//div[@class='px-0']/div/ul/li[1]/a").click()
time.sleep(3)
driver.find_element_by_name("gist[description]").clear()
driver.find_element_by_name("gist[description]").send_keys("My First Public Gist")
driver.find_element_by_xpath("//input[@name='new_filename']/preceding-sibling::input[1]").clear()
driver.find_element_by_xpath("//input[@name='new_filename']/preceding-sibling::input[1]").send_keys("helloworld_edit.py")
driver.find_element_by_xpath("//span[@role='presentation']").send_keys("\nprint('hello, world2')")
driver.execute_script("window.scrollTo(0, 1000);")
driver.find_element_by_xpath("//div[@class='form-actions']/button").click()
driver.find_element_by_xpath("//div[@id='user-links']/details[1]/summary[1]").click()
driver.find_element_by_xpath("//form[@class='logout-form']").click()
driver.find_element_by_xpath("//form/input[2]").click()