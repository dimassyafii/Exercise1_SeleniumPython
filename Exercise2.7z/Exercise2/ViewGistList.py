import time
from selenium import webdriver

driver = webdriver.Chrome(executable_path="C:\\chromedriver.exe")
driver.maximize_window()
driver.get("https://github.com/login")
driver.find_element_by_name("login").send_keys("testgistgithub")
driver.find_element_by_name("password").send_keys("Exercise_2")
driver.find_element_by_name("commit").click()
driver.get("https://gist.github.com")
driver.find_element_by_link_text("View your gists").click()
time.sleep(3)
driver.find_element_by_xpath("//div[@id='user-links']/details[1]/summary[1]").click()
driver.find_element_by_xpath("//form[@class='logout-form']").click()
driver.find_element_by_xpath("//form/input[2]").click()